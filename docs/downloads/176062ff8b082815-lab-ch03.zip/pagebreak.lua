
function Div(el)
  if el.classes:includes("pagebreak") then
    if FORMAT:match("latex") then
      return pandoc.RawBlock("latex", "\\newpage")
    elseif FORMAT:match("docx") then
      return pandoc.RawBlock(
        "openxml",
        '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'
      )
    elseif FORMAT:match("html") then
      return pandoc.RawBlock(
        "html",
        '<div style="page-break-after: always;"></div>'
      )
    end
  end
end
